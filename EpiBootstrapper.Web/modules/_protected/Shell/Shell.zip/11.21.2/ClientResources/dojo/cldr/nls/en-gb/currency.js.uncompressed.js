define(
"dojo/cldr/nls/en-gb/currency", //begin v1.x content
{
	"HKD_displayName": "Hong Kong Dollar",
	"CAD_displayName": "Canadian Dollar",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Chinese Yuan",
	"AUD_displayName": "Australian Dollar",
	"CAD_symbol": "CA$",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "British Pound",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "Euro"
}
//end v1.x content
);